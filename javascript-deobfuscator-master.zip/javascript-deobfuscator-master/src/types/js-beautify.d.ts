declare module 'js-beautify';
