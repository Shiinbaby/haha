declare module 'shift-codegen';
