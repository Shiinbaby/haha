declare module 'shift-parser';
