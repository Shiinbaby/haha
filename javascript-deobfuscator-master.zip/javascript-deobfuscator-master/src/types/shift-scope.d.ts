declare module 'shift-scope';
