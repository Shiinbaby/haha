declare module 'shift-validator';
